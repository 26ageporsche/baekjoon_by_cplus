#include<iostream>
using namespace std;
int main()
{
	int N, K;
	cin >> N >> K;

	// ���丮�� ����.
	int T = N - K;
	int sum_T = 1;
	int sum_N = 1;
	for (int i = 1; i <= T; i++)
	{
		sum_T *= i;
	}
	for (int i = K + 1; i <= N; i++)
	{
		sum_N *= i;
	}

	cout << sum_N / sum_T;
}