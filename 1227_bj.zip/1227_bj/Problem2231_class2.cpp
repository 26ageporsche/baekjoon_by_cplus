#include<iostream>
using namespace std;
int main()
{
	int x; // ������
	cin >> x;
	int check = 1000000;
	int save_min = 1000001;
	for (int i = 1; i <= 1000000; i++)
	{

		int sum = 0;
		int save = i;
		sum = i;
		while (save != 0) // check = 100 �϶�
		{
			sum += save % 10;
			save = save / 10;
		}

		if (x == sum)
		{
			if (save_min > i)
			{
				save_min = i;
			}
		}
	}
	if (save_min == 1000001)
	{
		cout << 0;
		return 0;
	}
	cout << save_min;
	return 0;
}