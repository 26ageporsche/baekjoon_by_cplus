#include<iostream>
#include<vector>

using namespace std;
int main()
{
	vector<int> arr;
	int t;
	cin >> t;


	for (int i = 0; i < t; i++)
	{
		char a;
		cin >> a;
		arr.push_back((int)(a - 'a' + 1));
	}
	long long k = 1;
	long long sum = 0;
	for (auto& e : arr)
	{
		sum += (e * k) % 1234567891;
		k *= 31;
		k %= 1234567891;
	}

	cout << sum;
}