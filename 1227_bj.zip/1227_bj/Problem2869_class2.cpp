#include<iostream>
using namespace std;

int main()
{
	long long A, B, V;
	cin >> A >> B >> V;


	long long C = A - B;
	
	if (((V - A) % C) == 0)
	{
		cout << (V - A) / C + 1;
	}
	else
	{
		cout << (V - A) / C + 2;

	}

}
// 20 2 40 18  20 % 2 = 10       