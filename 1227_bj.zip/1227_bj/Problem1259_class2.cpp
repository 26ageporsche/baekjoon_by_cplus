#include<iostream>
using namespace std;

int multiten(int t)
{
	int num = 1;
	for (int i = 0; i < t; i++)
	{
		num *= 10;
	}
	return num;
}
// 10 100 1000 10000 100000
int main()
{
	int num;
	cin >> num;
	while (num !=0)
	{

		// �ڸ��� üũ
		int cnt = 0;
		int save_num = num;
		while (save_num != 0)
		{
			save_num /= 10;
			cnt++;
		}

		int first = 1;
		int k = 1;
		int end = cnt;
		int flag = 0; // 0�̸� ���� ��
		while (first < end)
		{
			if ((num % multiten(first)) / k != (num / multiten(end - 1)) % 10) // 12421
			{
				flag++;
			}
			first++;
			end--;
			k = k * 10;
		}

		if (flag >= 1)
		{
			cout << "no" << '\n';
		}
		else
		{
			cout << "yes" << '\n';
		}

		cin >> num;
	}
	
}