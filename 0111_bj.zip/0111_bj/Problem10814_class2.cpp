#include<iostream>
#include<queue>
#include<string>

class Person
{
public:
	int age;
	int idx;
	std::string name;
	Person(int age_, std::string name_, int idx_) : age(age_), name(name_),idx(idx_) {};
};

class comparePerson
{
public:
	bool operator()(Person& p1, Person& p2)
	{
		if (p1.age == p2.age)
		{
			return p1.idx > p2.idx;
		}
		return p1.age > p2.age;
	}
};
int main()
{
	std::priority_queue<Person, std::vector<Person>, comparePerson> mypqueue;
	int n;
	int age_;

	std::string name_;
	std::cin >> n;

	// �켱������ ����
	for (int i = 0; i < n; i++)
	{
		std::cin >> age_ >> name_;
		Person t(age_, name_,i);
		mypqueue.push(t);
	}

	for (int i = 0; i < n; i++)
	{
		std::cout << mypqueue.top().age << " " << mypqueue.top().name << '\n';
		mypqueue.pop();
	}

	return 0;
}