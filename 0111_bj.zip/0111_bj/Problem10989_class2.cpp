//#include<iostream>
//#include<queue>
//
//int main()
//{
//	std::priority_queue<int, std::vector<int>, std::greater<int> > mypqueue;
//
//	long N;
//	std::cin >> N;
//	for (long i = 0; i < N; i++)
//	{
//		int t;
//		std::cin >> t;
//		mypqueue.push(t);
//	}
//
//	for (long i = 0; i < N;i++)
//	{
//		std::cout << mypqueue.top() << '\n';
//		mypqueue.pop();
//	}
//
//	return 0;
//}

#include<iostream>
int arr[10002] = { 0, };
int main()
{
	std::ios::sync_with_stdio(false);

	std::cin.tie(NULL);

	std::cout.tie(NULL);

	long N;
	std::cin >> N;

	for (long i = 0; i < N; i++)
	{
		long t;
		std::cin >> t;
		arr[t]++;
	}
	long num = 1;
	long cnt = 0;
	while (cnt != N)
	{
		for (long i = 0; i < arr[num]; i++)
		{
			std::cout << num << '\n';
			cnt++;
		}
		num++;
	}

	return 0;
}