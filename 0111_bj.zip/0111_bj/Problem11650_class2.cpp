#include<iostream>
#include<queue>

class Person
{
public:
	int x;
	int y;
	Person(int x_, int y_) : x(x_), y(y_) {};
};

class compare_xy
{
public:
	bool operator()(Person& p1, Person& p2)
	{
		if (p1.y == p2.y)
		{
			return p1.x > p2.x;
		}
		return p1.y > p2.y;
	}
};

int main()
{
	int N;
	std::cin >> N;
	std::priority_queue<Person, std::vector<Person>, compare_xy> mypqueue;
	for (int i = 0; i < N; i++)
	{
		int x;
		int y;

		std::cin >> x >> y;
		Person t(x, y);
		mypqueue.push(t);
	}

	for (int i = 0; i < N; i++)
	{
		std::cout << mypqueue.top().x << " " << mypqueue.top().y << '\n';
		mypqueue.pop();
	}

}