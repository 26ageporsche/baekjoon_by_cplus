#include<iostream>

int arr[100001] = { 0, };

int main()
{
	int N;
	std::cin >> N;
	int size = N;
	int idx = -1;
	while(size > 0)
	{
		int t;
		std::cin >> t;
		if (t != 0)
		{
			idx++;
			arr[idx] = t;
		}
		else
		{
			arr[idx] = 0;
			idx--;
		}
		size--;
	}
	int sum = 0;
	for (int i = 0; i <= idx; i++)
	{
		sum += arr[i];
	}
	std::cout << sum;


	return 0;
}