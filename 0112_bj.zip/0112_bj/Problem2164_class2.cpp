#include<iostream>

int arr[1500000] = { 0, };

int main()
{
	int N;
	std::cin >> N;
	for (int i = 1; i <= N; i++)
	{
		arr[i] = i;
	}
	if (N == 1) 
	{ 
		std::cout << 1; 
		return 0;
	}
	int cnt = 1;
	int Max_idx = N;
	while (Max_idx != N + (N - 2))
	{
		// ����
		arr[cnt] = 0;
		// �̵�
		arr[Max_idx + 1] = arr[cnt + 1];
		arr[cnt + 1] = 0;

		Max_idx++;
		cnt += 2;
	}
	std::cout << arr[Max_idx];

	return 0;
}