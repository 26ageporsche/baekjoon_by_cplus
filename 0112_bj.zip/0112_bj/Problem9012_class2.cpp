#include<iostream>
#include<string>

std::string arr;
int check[100001] = { 0, };
int print[100001] = { 0, };
int main()
{
	int cnt = -1;
	int N;
	std::cin >> N;
	std::getchar();

	for (int t = 0; t < N; t++)
	{
		cnt++;
		int i = 0;
		int flag = 0;
		int idx = -1;
		std::getline(std::cin, arr);
		i = arr.size();
		for (int k = 0; k <= i; k++)
		{
			if (arr[k] == '(')
			{
				idx++;
				check[idx] = 1;
			}
			else if (arr[k] == ')')
			{
				if (idx < 0)
				{
					flag++;
					break;
				}
				else
				{
					if (check[idx] != 1)
					{
						flag++;
						break;
					}
					else
					{
						check[idx] = 0;
						idx--;
					}
				}
			}
			else if (arr[k] == '[')
			{
				idx++;
				check[idx] = 2;
			}
			else if (arr[k] == ']')
			{
				if (idx < 0)
				{
					flag++;
					break;
				}
				else
				{
					if (check[idx] != 2)
					{
						flag++;
						break;
					}
					else
					{
						check[idx] = 0;
						idx--;
					}
				}
			}
		}
		if (flag != 0 || idx != -1) // �ϳ��� Ʋ������
		{
			print[cnt] = -1;
		}
		else
		{
			print[cnt] = 0;
		}


	}

	for (int i = 0; i <= cnt; i++)
	{
		if (print[i] == 0)
		{
			std::cout << "YES" << '\n';
		}
		else
		{
			std::cout << "NO" << '\n';
		}
	}
	return 0;
}
