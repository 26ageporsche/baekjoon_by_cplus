#include<iostream>
int arr[101];
int main()
{
	int N;
	std::cin >> N;
	for (int i = 0; i < N; i++)
	{
		int t;
		std::cin >> t;
		arr[i] = t;
	}
	int sum = 0;
	for (int i = 0; i < N; i++)
	{
		int cnt = 0;
		for (int k = 1; k <= arr[i]; k++)
		{
			if (arr[i] % k == 0) cnt++;
		}
		if (cnt == 2)  sum++;
	}
	std::cout << sum;
	return 0;
}