#include<iostream>

int main()
{
	int N;
	std::cin >> N;

	if (N <= 5)
	{
		long sum = 0;
		int t = 1;
		for (int i = 0; i < N; i++)
		{
			char a;
			std::cin >> a;
			sum += (a - 'a' + 1) * t;
			t *= 31;
		}

		std::cout << sum;
		return 0;
	}
	else
	{
		long long sum = 0;
		long long t = 1;
		for (int i = 0; i < N; i++)
		{
			char a;
			std::cin >> a;
			sum = (sum + (a - 'a' + 1) * t) % 1234567891;
			t = (t * 31) % 1234567891;
		}

		std::cout << sum;
		return 0;
	}



}