#include<iostream>
// �Ĵ°� 2�� ���°� 1��.

int arr[250001] = { 0, };
// ��ǥ�� arr[i/M][i % M] �� ���� �ۿ�ǰ� �� ��


int main()
{
	int N, M, B;
	std::cin >> N >> M >> B;
	int sum = 0;
	int min = 10000;
	int max = 0;
	for (int i = 0; i < N * M; i++)
	{
		int t;
		std::cin >> t;
		arr[i] = t;
		sum += t;
		if (t > max)
		{
			max = t;
		}
		if (t < min)
		{
			min = t;
		}
	}

	long min_sec = 300000000;
	int height = 0;
	for (int i = min; i <= max; i++)
	{
		long sum = 0;
		int block_num = B;
		for (int k = 0; k < N * M; k++)
		{
			if (arr[k] > i)
			{
				sum += (arr[k] - i) * 2;
				block_num += (arr[k] - i);
			}
			else if (arr[k] < i)
			{
				sum += (i - arr[k]);
				block_num -= (i-arr[k]);
			}
		}
		if (min_sec >= sum && block_num >= 0)
		{
			min_sec = sum;
			height = i;
		}
	}
	std::cout << min_sec << " " << height;
	return 0;
}