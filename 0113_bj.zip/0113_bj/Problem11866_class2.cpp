#include<iostream>
int arr[1002] = { 0, };
int main()
{
	int N, K;
	std::cin >> N;
	for (int i = 0; i < N; i++)
	{
		arr[i] = i+1;
	}

	std::cin >> K;
	int idx = -1;
	int cnt = 0;
	int size = N; // 7
	std::cout << "<";
	while (cnt != N)
	{
		int flag = 0;
		while (flag != K)
		{
			idx++;
			if (arr[idx % size] != 0)
			{
				flag++;
			}
		}
		if (cnt != N - 1)
		{
			std::cout << arr[idx % size] << ", ";
			arr[idx % size] = 0;
		}
		else
		{
			std::cout << arr[idx % size];
			arr[idx % size] = 0;
		}
		cnt++;
	}
	std::cout << ">";

	return 0;
}