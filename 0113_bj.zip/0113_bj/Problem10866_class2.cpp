#include<iostream>
#include<string>
#include<vector>
#include<string.h>

std::vector<int> arr;
char push_front[100] = { 'p','u','s','h','_','f','r','o','n','t', 0, };
char push_back[100] = { 'p','u','s','h','_','b','a','c','k', 0, };
char pop_front[100] = { 'p','o','p','_','f','r','o','n','t',0, };
char pop_back[100] = { 'p','o','p','_','b','a','c','k',0, };
char empty[100] = { 'e','m','p','t','y',0, };
char size[100] = { 's','i','z','e',0, };
char front[100] = { 'f','r','o','n','t',0, };
char back[100] = { 'b','a','c','k',0, };

int main()
{
	int N;
	std::cin >> N;
	for (int i = 0; i < N; i++)
	{
		char a[100];
		std::cin >> a;
		if (strcmp(push_front, a) == 0)
		{
			int t;
			std::cin >> t;
			if (arr.size() != 0)
			{
				arr.insert(arr.begin(), t);
			}
			else
			{
				arr.push_back(t);
			}
		}
		else if (strcmp(push_back, a) == 0)
		{
			int t;
			std::cin >> t;
			arr.push_back(t);
		}
		else if (strcmp(pop_front, a) == 0)
		{
			if (arr.empty() == 1)
			{
				std::cout << "-1" << '\n';
			}
			else
			{
				std::cout << *(arr.begin()) << '\n';
				arr.erase(arr.begin());
			}
		}
		else if (strcmp(pop_back, a) == 0)
		{
			if (arr.empty() == 1)
			{
				std::cout << "-1" << '\n';
			}
			else
			{
				std::cout << *(arr.rbegin()) << '\n';
				arr.pop_back();
			}
		}
		else if (strcmp(size, a) == 0)
		{
			std::cout << arr.size() << '\n';
		}
		else if (strcmp(empty, a) == 0)
		{
			if (arr.size() == 0)
			{
				std::cout << "1" << '\n';
			}
			else
			{
				std::cout << "0" << '\n';
			}
		}
		else if (strcmp(front, a) == 0)
		{
			if (arr.size() == 0)
			{
				std::cout << "-1" << '\n';
			}
			else
			{
				std::cout << *(arr.begin()) << '\n';
			}
		}
		else if (strcmp(back, a) == 0)
		{
			if (arr.size() == 0)
			{
				std::cout << "-1" << '\n';
			}
			else
			{
				std::cout << *(arr.rbegin()) << '\n';
			}
		}

	}

	return 0;
}