#include<iostream>
#include<string>
#include<vector>
#include<string.h>

std::vector<int> arr;
char push[100] = { 'p','u','s','h',0,};
char top[100] = { 't','o','p',0, };
char empty[100] = { 'e','m','p','t','y',0, };
char pop[100] = { 'p','o','p',0, };
char size[100] = { 's','i','z','e',0, };

int main()
{
	int N;
	std::cin >> N;
	for (int i = 0; i < N; i++)
	{
		char a[100];
		std::cin >> a;
		if (strcmp(push,a) == 0)
		{
			int t;
			std::cin >> t;
			arr.push_back(t);
		}
		else if (strcmp(top, a) == 0)
		{
			if (arr.size() == 0)
			{
				std::cout << "-1" << '\n';
			}
			else
			{
				std::cout << *(arr.rbegin()) << '\n';
			}
		}
		else if (strcmp(empty, a) == 0)
		{
			if (arr.size() == 0)
			{
				std::cout << "1" << '\n';
			}
			else
			{
				std::cout << "0" << '\n';
			}
		}
		else if (strcmp(pop, a) == 0)
		{
			if (arr.empty() == 1)
			{
				std::cout << "-1" << '\n';
			}
			else
			{
				std::cout << *(arr.rbegin()) << '\n';
				arr.pop_back();
			}
		}
		else if (strcmp(size, a) == 0)
		{
			std::cout << arr.size() << '\n';
		}

	}

	return 0;
}