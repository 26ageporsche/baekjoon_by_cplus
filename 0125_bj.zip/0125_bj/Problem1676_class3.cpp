#include<iostream>

int main()
{
	int t;
	std::cin >> t;

	int a = t / 5;
	int b = t / 25;
	int c = t / 125;
	std::cout << a + b + c << '\n';

	return 0;
}