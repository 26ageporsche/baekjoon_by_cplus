#include<iostream>
#include<map>
#include<string>

std::map<std::string, std::string> arr;

int main()
{
	std::cin.tie(NULL);
	std::ios::sync_with_stdio(false);
	std::cout.tie(NULL);

	int N, M;
	std::cin >> N >> M;

	for (int i = 0; i < N; i++)
	{
		char site[21];
		char password[21];
		std::cin >> site >> password;
		std::string site_ = site;
		std::string password_ = password;
		arr.insert({ site_,password_ });
	}

	for (int i = 0; i < M; i++)
	{
		char site[21];
		std::cin >> site;
		auto a = arr.find(site);
		std::cout << (*a).second << '\n';
	}

	return 0;
}