#include<iostream>
#include<map>
#include<string>

std::map < std::string, int > arr;
std::map <std::string, int > print;
int main()
{
	int N, M;
	std::cin >> N >> M;
	for (int i = 0; i < N; i++)
	{
		std::string t;
		std::cin >> t;
		arr.insert({ t,1 });
	}
	for (int i = 0; i < M; i++)
	{
		std::string t;
		std::cin >> t;
		auto a = arr.find(t);
		if (a != arr.end()) // �ִ�
		{
			print.insert({ t,1 });
		}
	}
	std::cout << print.size() << '\n';
	for (auto& e : print)
	{
		std::cout << e.first << '\n';
	}

	return 0;
}