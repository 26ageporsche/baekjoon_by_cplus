#include<iostream>
int main()
{
	int a, b;
	std::cin >> a >> b;

	int max_num = 0;
	int min_multi = 0;
	if (a > b)
	{
		for (int i = 1; i <= b; i++)
		{
			if (a % i == 0 && b % i == 0)
			{
				max_num = i;
			}
		}
		min_multi = (b / max_num) * a;
	}
	else
	{
		for (int i = 1; i <= a; i++)
		{
			if (a % i == 0 && b % i == 0)
			{
				max_num = i;
			}
		}
		min_multi = (a / max_num) * b;
	}

	std::cout << max_num << '\n';
	std::cout << min_multi << '\n';


	return 0;
}