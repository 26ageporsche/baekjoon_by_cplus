#include<iostream>

int weight_[50] = { 0, };
int height_[50] = { 0, };
int rank[50] = {0,};

int main()
{
	int N, weight, height;
	std::cin >> N;
	
	// ��� �־� �� ����
	for (int i = 0; i < N; i++)
	{
		std::cin >> weight >> height;
		weight_[i] = weight;
		height_[i] = height;
	}
	int cnt = 1;
	int weight_idx;
	int max_weight = 0;
	int height_idx;
	int max_height = 0;
	int cnt_flag = 0;
	while (1)
	{
		cnt_flag = 0;
		for (int i = 0; i < N; i++) // ���� ū���� ã�� ��
		{
			if (rank[i] == 0 && weight_[i] > max_weight)
			{
				weight_idx = i;
				max_weight = weight_[i];
			}
			if (rank[i] == 0 && height_[i] > max_height)
			{
				height_idx = i;
				max_height = height_[i];
			}
		}
		if (height_idx == weight_idx)
		{
			rank[height_idx] == cnt;
			cnt++;
		}
		else
		{
			for (int i = 0; i < N; i++)
			{
				if (rank[i] == 0 && ((weight_[i] > weight_[height_idx] && height_[i] < height_[weight_idx]) || (height_[i] > height_[weight_idx] && weight_[i] < weight_[height_idx])))
				{
					rank[i] = cnt;
					cnt_flag++;
				}
			}
			cnt = cnt + cnt_flag;
		}
	}
	for (int i = 0; i < N; i++)
	{
		std::cout << rank[i] << " ";
	}

	return 0;
}